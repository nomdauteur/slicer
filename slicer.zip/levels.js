levels=[
{slices:[4], speed: 40},
{slices:[4,8], speed: 40},
{slices:[4,4,4,8], speed: 40},
{slices:[2,4,8], speed: 40},
{slices:[2,4,4], speed: 40},
{slices:[2,3,10], speed: 40},
{slices:[2,3,6], speed: 40},
{slices:[4,4,8,8], speed: 40},
{slices:[5,5,5,5], speed: 40},
{slices:[6,5,4,3], speed: 40},
{slices:[8,8,8,8,4,4], speed: 40}
]